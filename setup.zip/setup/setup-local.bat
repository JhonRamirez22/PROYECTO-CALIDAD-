@echo off
title RiTech Export - Local Setup
echo.
echo ====================================
echo   RiTech Export System - Local Setup
echo   PostgreSQL 16 + pgAdmin 4
echo ====================================
echo.
echo This will install:
echo   - PostgreSQL 16 (database)
echo   - pgAdmin 4 (database GUI)
echo   - Create database and seed data
echo.
echo You need Administrator rights.
echo.

:: Check admin rights
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Not running as Administrator.
    echo     Right-click this file ^> Run as administrator
    echo.
    pause
    exit /b 1
)

:: Run PowerShell script
powershell -ExecutionPolicy Bypass -File "%~dp0setup-local.ps1"

echo.
pause
