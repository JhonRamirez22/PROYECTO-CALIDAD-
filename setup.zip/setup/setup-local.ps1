#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Setup local development environment for RiTech Export System
.DESCRIPTION
    Installs PostgreSQL 16 + pgAdmin 4, creates database, runs migrations and seed.
.NOTES
    Run as Administrator: Right-click > Run as Administrator
    Or from PowerShell: .\setup-local.ps1
#>

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

# ─── Configuration ──────────────────────────────────────────
$DB_NAME     = "ritech_export"
$DB_USER     = "ritech"
$DB_PASSWORD = "ritech123"
$DB_PORT     = 5432
$PG_VERSION  = "16"
$PROJECT_ROOT = Split-Path -Parent $PSScriptRoot

# ─── Colors ─────────────────────────────────────────────────
function Write-Step  { param($msg) Write-Host "`n>> $msg" -ForegroundColor Cyan }
function Write-OK    { param($msg) Write-Host "   [OK] $msg" -ForegroundColor Green }
function Write-Warn  { param($msg) Write-Host "   [!] $msg" -ForegroundColor Yellow }
function Write-Err   { param($msg) Write-Host "   [X] $msg" -ForegroundColor Red }

Write-Host @"
=====================================
  RiTech Export System - Local Setup
  PostgreSQL $PG_VERSION + pgAdmin 4
=====================================
"@ -ForegroundColor Yellow

# ─── 1. Check prerequisites ────────────────────────────────
Write-Step "Checking prerequisites..."

# Check Node.js
$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
    Write-Err "Node.js not found. Install from https://nodejs.org (LTS)"
    exit 1
}
$nodeVersion = node --version
Write-OK "Node.js $nodeVersion"

# Check npm
$npm = Get-Command npm -ErrorAction SilentlyContinue
if (-not $npm) {
    Write-Err "npm not found"
    exit 1
}
Write-OK "npm $(npm --version)"

# Check winget
$winget = Get-Command winget -ErrorAction SilentlyContinue
if (-not $winget) {
    Write-Err "winget not found. Install App Installer from Microsoft Store"
    exit 1
}
Write-OK "winget available"

# ─── 2. Install PostgreSQL ─────────────────────────────────
Write-Step "Installing PostgreSQL $PG_VERSION..."

$pgInstalled = winget list --name "PostgreSQL" 2>$null | Select-String "PostgreSQL"
if ($pgInstalled) {
    Write-Warn "PostgreSQL already installed, skipping"
} else {
    Write-Host "   Downloading and installing PostgreSQL $PG_VERSION..." -ForegroundColor Gray
    winget install --id PostgreSQL.PostgreSQL.$PG_VERSION --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        Write-Err "PostgreSQL installation failed. Try installing manually from https://www.postgresql.org/download/windows/"
        exit 1
    }
    Write-OK "PostgreSQL $PG_VERSION installed"
}

# ─── 3. Install pgAdmin 4 ──────────────────────────────────
Write-Step "Installing pgAdmin 4..."

$pgAdminInstalled = winget list --name "pgAdmin" 2>$null | Select-String "pgAdmin"
if ($pgAdminInstalled) {
    Write-Warn "pgAdmin 4 already installed, skipping"
} else {
    Write-Host "   Downloading and installing pgAdmin 4..." -ForegroundColor Gray
    winget install --id PostgreSQL.pgAdmin --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        Write-Warn "pgAdmin install failed (non-critical). You can install manually later."
    } else {
        Write-OK "pgAdmin 4 installed"
    }
}

# ─── 4. Find psql ──────────────────────────────────────────
Write-Step "Locating psql..."

$pgBinPaths = @(
    "C:\Program Files\PostgreSQL\$PG_VERSION\bin",
    "C:\Program Files\PostgreSQL\16\bin",
    "C:\Program Files\PostgreSQL\15\bin"
)

$psqlPath = $null
foreach ($p in $pgBinPaths) {
    if (Test-Path "$p\psql.exe") {
        $psqlPath = "$p\psql.exe"
        break
    }
}

if (-not $psqlPath) {
    # Try system PATH
    $psqlCmd = Get-Command psql -ErrorAction SilentlyContinue
    if ($psqlCmd) {
        $psqlPath = $psqlCmd.Source
    }
}

if (-not $psqlPath) {
    Write-Err "psql.exe not found. Ensure PostgreSQL bin is in your PATH."
    Write-Host "   Typical path: C:\Program Files\PostgreSQL\$PG_VERSION\bin" -ForegroundColor Gray
    exit 1
}
Write-OK "psql found at: $psqlPath"

# Add to PATH for this session
$pgBinDir = Split-Path $psqlPath
if ($env:PATH -notlike "*$pgBinDir*") {
    $env:PATH = "$pgBinDir;$env:PATH"
}

# ─── 5. Wait for PostgreSQL service ────────────────────────
Write-Step "Waiting for PostgreSQL service to start..."

$pgService = Get-Service -Name "postgresql*" -ErrorAction SilentlyContinue | Select-Object -First 1
if ($pgService) {
    if ($pgService.Status -ne "Running") {
        Write-Host "   Starting PostgreSQL service..." -ForegroundColor Gray
        Start-Service $pgService.Name -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 3
    }
    Write-OK "PostgreSQL service running: $($pgService.Name)"
} else {
    Write-Warn "No PostgreSQL Windows service found. Trying to connect anyway..."
}

# ─── 6. Create database and user ───────────────────────────
Write-Step "Creating database '$DB_NAME' and user '$DB_USER'..."

# Connect as postgres superuser (default install)
$env:PGPASSWORD = "postgres"

# Try to create user
$userCheck = & $psqlPath -U postgres -h localhost -tAc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" 2>$null
if ($userCheck -ne "1") {
    & $psqlPath -U postgres -h localhost -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD' SUPERUSER;"
    Write-OK "User '$DB_USER' created"
} else {
    # Update password
    & $psqlPath -U postgres -h localhost -c "ALTER USER $DB_USER WITH PASSWORD '$DB_PASSWORD';"
    Write-OK "User '$DB_USER' password updated"
}

# Try to create database
$dbCheck = & $psqlPath -U postgres -h localhost -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" 2>$null
if ($dbCheck -ne "1") {
    & $psqlPath -U postgres -h localhost -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
    Write-OK "Database '$DB_NAME' created"
} else {
    Write-Warn "Database '$DB_NAME' already exists"
}

# ─── 7. Create .env.local for API ──────────────────────────
Write-Step "Creating apps/api/.env.local..."

$apiEnvContent = @"
# Local PostgreSQL (localhost)
DATABASE_URL="postgresql://${DB_USER}:${DB_PASSWORD}@localhost:${DB_PORT}/${DB_NAME}"
DIRECT_URL="postgresql://${DB_USER}:${DB_PASSWORD}@localhost:${DB_PORT}/${DB_NAME}"

# Supabase (still needed for some features)
SUPABASE_URL="https://xunbgriagsdiiiqlrnqk.supabase.co"
SUPABASE_ANON_KEY="sb_publishable_HeZKnMAjIrFhGcBC32e-MQ_ncksOFIt"
SUPABASE_SERVICE_ROLE_KEY="sb_secret_M0dVNj1mU5RzEuf4-Qe29A_mFkJaugw"

# App
DEFAULT_COMMISSION_RATE=0.01
JWT_SECRET="ritech-export-secret-2024"
NODE_ENV=development
PORT=3001

# Stripe Test Keys
STRIPE_SECRET_KEY="sk_test_51Tf1ABDYKlVzzmBwilt52JNu5MLWBEV7pE4rAoZs7TG3T7yjh4hVlsphMiFudJqZxuU97zo8EMDhFWldRFFMwpZu00DRoL3Z92"
STRIPE_PUBLISHABLE_KEY="pk_test_51Tf1ABDYKlVzzmBwvMQz41TKZOY58dPKDChn5FT6ljwNpo7smHMERZthE9tXsLikj5ZOi8785lRHlE7PFGFc5zYN00sqUbaya2"
STRIPE_WEBHOOK_SECRET="whsec_..."
"@

$apiEnvPath = Join-Path $PROJECT_ROOT "apps\api\.env.local"
Set-Content -Path $apiEnvPath -Value $apiEnvContent -Encoding UTF8
Write-OK "apps/api/.env.local created"

# ─── 8. Create .env.local for Frontend ─────────────────────
Write-Step "Verifying apps/web/.env.local..."

$webEnvPath = Join-Path $PROJECT_ROOT "apps\web\.env.local"
$webEnvContent = @"
NEXT_PUBLIC_SUPABASE_URL="https://xunbgriagsdiiiqlrnqk.supabase.co"
NEXT_PUBLIC_SUPABASE_ANON_KEY="sb_publishable_HeZKnMAjIrFhGcBC32e-MQ_ncksOFIt"
NEXT_PUBLIC_API_URL="http://localhost:3001"
"@

Set-Content -Path $webEnvPath -Value $webEnvContent -Encoding UTF8
Write-OK "apps/web/.env.local verified"

# ─── 9. Install dependencies ───────────────────────────────
Write-Step "Installing npm dependencies..."

Push-Location $PROJECT_ROOT
npm install 2>$null
Pop-Location
Write-OK "Dependencies installed"

# ─── 10. Run Prisma migrations ─────────────────────────────
Write-Step "Running Prisma migrations..."

Push-Location (Join-Path $PROJECT_ROOT "apps\api")
npx prisma generate 2>$null
npx prisma migrate dev --name init 2>$null
Pop-Location
Write-OK "Migrations applied"

# ─── 11. Seed database ─────────────────────────────────────
Write-Step "Seeding database..."

Push-Location $PROJECT_ROOT
npm run db:seed 2>$null
Pop-Location
Write-OK "Database seeded"

# ─── 12. Done ──────────────────────────────────────────────
Write-Host @"

=====================================
  Setup Complete!
=====================================

Database:
  Host:     localhost
  Port:     $DB_PORT
  Database: $DB_NAME
  User:     $DB_USER
  Password: $DB_PASSWORD

pgAdmin 4:
  Open from Start Menu > pgAdmin 4
  Right-click Servers > Register > Server
  Host: localhost, Port: $DB_PORT
  User: $DB_USER, Password: $DB_PASSWORD

Login credentials (app):
  admin@ritech.com       / admin123
  propietario@ritech.com / propietario123
  comprador@ritech.com   / comprador123
  vendedor@ritech.com    / vendedor123
  logistica@ritech.com   / logistica123
  cliente@ritech.com     / cliente123

To start the project:
  Option A: Double-click  setup\start-local.bat
  Option B: Run manually:
    npm run dev:api   (API on http://localhost:3001)
    npm run dev:web   (Web on http://localhost:3000)

Open http://localhost:3000 in your browser.
=====================================
"@ -ForegroundColor Green
